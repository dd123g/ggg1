var Clock = "24h";	         // choose between "12h" or "24h".
var lang = "ru";	             // choose between "sp", "en", "de" or "ru".